﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Models
{
    public class Knapsack
    {
        public string Task { get; set; }
        public string Status { get; set; }
        public Timestamps TimeStamps { get; set; }

        public Problem Problem { get; set; }
        public Solution Solution { get; set; }

    }
}
