﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Models
{
    public class KnapsackProblem
    {
        public Problem problem { get; set; }
    }
    public class Problem
    {
        public long capacity { get; set; }
        public long[] weights { get; set; }
        public long[] values { get; set; }
    }
}
