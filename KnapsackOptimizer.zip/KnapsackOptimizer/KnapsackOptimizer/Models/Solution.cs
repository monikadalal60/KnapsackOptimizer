﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Models
{
    public class Solution
    {
        public List<long> PackedItems { get; set; }
        public double TotalValue { get; set; }
        [JsonIgnore]
        public bool IsCompleted { get; set; }
    }
}
