﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Models
{
    public enum Status
    {
        submitted,
        started,
        completed
    }
}
