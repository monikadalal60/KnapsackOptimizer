﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Models
{
    public class Timestamps
    {
        public DateTime? Submitted { get; set; }
        public DateTime? Started { get; set; }
        public DateTime? Completed { get; set; }
    }
}
