﻿using KnapsackOptimizer.Models;
using KnapsackOptimizer.Business;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Controllers
{
    [ApiController]
    public class KnapsackController : ControllerBase
    {
        IKnapsackSolver _solver;
        public KnapsackController(IKnapsackSolver solver)
        {
            _solver = solver;
        }

        [HttpGet]
        [Route("knapsack/{id}")]
        public async Task<IActionResult> GetKnapsack(string id)
        {
            var result = await _solver.GetKnapsack(id);
            return Ok(result);
        }

        [HttpPost("knapsack")]
        public async Task<IActionResult> CreateKnapsack([FromBody] KnapsackProblem problem)
        {
            var result = await _solver.CreateKnapsack(problem.problem);
            return Ok(result);
        }

    }
}
