﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KnapsackOptimizer.Models;

namespace KnapsackOptimizer.Business
{
    public interface IKnapsackSolver
    {
        public Task<Knapsack> GetKnapsack(string id);
        public Task<Knapsack> CreateKnapsack(Problem problem);
    }
}
