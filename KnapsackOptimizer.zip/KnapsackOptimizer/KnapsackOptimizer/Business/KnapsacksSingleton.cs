﻿using KnapsackOptimizer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KnapsackOptimizer.Business
{
    public sealed class KnapsacksSingleton
    {
        private static readonly KnapsacksSingleton instance = new KnapsacksSingleton();
        public IDictionary<string, Knapsack> knapsacks = new Dictionary<string, Knapsack>();

        private KnapsacksSingleton()
        {

        }

        public static KnapsacksSingleton GetInstance
        {
            get
            {
                return instance;
            }
        }
    }
}
