﻿using KnapsackOptimizer.Models;
using System;
using System.Threading.Tasks;
using System.Linq;

namespace KnapsackOptimizer.Business
{
    public class KnapsackSolver : IKnapsackSolver
    {
        private Knapsack knapsack;
        private KnapsacksSingleton instance;
        private static Random random;
        public KnapsackSolver()
        {
            knapsack = new Knapsack();
            instance = KnapsacksSingleton.GetInstance;
            random = new Random();
        }
        public Task<Knapsack> CreateKnapsack(Problem problem)
        {
            try
            {
                knapsack.Task = RandomString(8);
                knapsack.Status = Status.submitted.ToString();
                knapsack.Problem = problem;
                knapsack.TimeStamps = GetTimeStamps(knapsack.Status);
                knapsack.Solution = null;
                instance.knapsacks.Add(knapsack.Task, knapsack);
                return Task.FromResult(knapsack);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private async void StartRunningAlgorithm(Knapsack knapsack)
        {
            await Task.Run(() => GetSolution(knapsack));
        }

        private void GetSolution(Knapsack knapsack)
        {
            try
            {
                Solution solution = new Solution();
                solution.PackedItems = new System.Collections.Generic.List<long>();
                int n = knapsack.Problem.values.Length;
                long W = knapsack.Problem.capacity;
                long i, w;
                long[,] K = new long[n + 1, W + 1];

                for (i = 0; i <= n; i++)
                {
                    for (w = 0; w <= W; w++)
                    {
                        if (i == 0 || w == 0)
                            K[i, w] = 0;
                        else if (knapsack.Problem.weights[i - 1] <= w)
                            K[i, w] = Math.Max(knapsack.Problem.values[i - 1] +
                                    K[i - 1, w - knapsack.Problem.weights[i - 1]], K[i - 1, w]);
                        else
                            K[i, w] = K[i - 1, w];
                    }
                }

                long res = K[n, W];
                solution.TotalValue = res;

                w = W;
                for (i = n; i > 0 && res > 0; i--)
                {
                    if (res == K[i - 1, w])
                        continue;
                    else
                    {
                        solution.PackedItems.Add(i - 1);
                        res = res - knapsack.Problem.values[i - 1];
                        w = w - knapsack.Problem.weights[i - 1];
                    }
                }
                solution.IsCompleted = true;
                instance.knapsacks[knapsack.Task].Solution = solution;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private Timestamps GetTimeStamps(string status)
        {
            Timestamps stamps = new Timestamps();
            switch (status)
            {
                case "submitted":
                    stamps.Submitted = DateTime.UnixEpoch;
                    stamps.Started = null;
                    stamps.Completed = null;
                    break;
                case "started":
                    stamps.Submitted = DateTime.UnixEpoch;
                    stamps.Started = DateTime.UnixEpoch;
                    stamps.Completed = null;
                    break;
                case "completed":
                    stamps.Submitted = DateTime.UnixEpoch;
                    stamps.Started = DateTime.UnixEpoch;
                    stamps.Completed = DateTime.UnixEpoch;
                    break;
                default:
                    break;
            }
            return stamps;
        }

        public Task<Knapsack> GetKnapsack(string id)
        {
            var knapsack = instance.knapsacks.Where(x => x.Key.Equals(id)).Select(y => y.Value).FirstOrDefault();
            if (knapsack != null)
            {
                if (knapsack.Solution != null && knapsack.Solution.IsCompleted)
                {
                    knapsack.Status = Status.completed.ToString();
                    knapsack.TimeStamps = GetTimeStamps(knapsack.Status);
                }
                else
                {
                    knapsack.Status = Status.started.ToString();
                    knapsack.TimeStamps = GetTimeStamps(knapsack.Status);
                    StartRunningAlgorithm(knapsack);
                }
            }

            return Task.FromResult(knapsack);
        }
    }
}
