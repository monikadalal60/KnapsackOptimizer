using NUnit.Framework;
using Moq;
using KnapsackOptimizer.Business;
using KnapsackOptimizer.Controllers;
using System.Collections.Generic;
using KnapsackOptimizer.Models;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace KnapsackOptimizer.Test
{
    public class KnapsackOptimizeControllerTests
    {
        private Mock<IKnapsackSolver> _mockKnapsackSolver;
        private KnapsackController _controller;
        [SetUp]
        public void Setup()
        {
            _mockKnapsackSolver = new Mock<IKnapsackSolver>();
            _controller = new KnapsackController(_mockKnapsackSolver.Object);
        }

        [Test]
        public void GetKnapsackTest()
        {
            //Arrange
            string id = "nbd43jhb";
            Knapsack knapsack = new Knapsack()
            {
                Task = "nbd43jhb",
                Status = Status.completed.ToString(),
                Problem = new Problem() { capacity = 60, weights = new long[] { 10, 20, 33 }, values = new long[] { 10, 3, 30 } },
                TimeStamps = new Timestamps() { Submitted = DateTime.UnixEpoch, Started = DateTime.UnixEpoch, Completed = DateTime.UnixEpoch },
                Solution = new Solution() { PackedItems = new List<long>() { 0, 2 }, TotalValue = 40, IsCompleted = true },
            };
            var expectedResult = Task.FromResult(knapsack);
            _mockKnapsackSolver.Setup(m => m.GetKnapsack(id)).Returns(expectedResult);

            //Act
            var actualResult = _controller.GetKnapsack(id);

            //Assert
            _mockKnapsackSolver.Verify(m => m.GetKnapsack(It.IsAny<string>()), Times.Once);
            Assert.IsNotNull(actualResult);
            Assert.IsInstanceOf(typeof(Task<IActionResult>), actualResult);
        }

        [Test]
        public void CreateKnapsackTest()
        {
            //Arrange
            KnapsackProblem problem = new KnapsackProblem() { problem = new Problem() { capacity = 60, weights = new long[] { 10, 20, 33 }, values = new long[] { 10, 3, 30 } } };
            Knapsack knapsack = new Knapsack()
            {
                Task = "nbd43jhb",
                Status = Status.submitted.ToString(),
                Problem = problem.problem,
                TimeStamps = new Timestamps() { Submitted = DateTime.UnixEpoch, Started = null, Completed = null },
                Solution = null,
            };
            var expectedResult = Task.FromResult(knapsack);
            _mockKnapsackSolver.Setup(m => m.CreateKnapsack(problem.problem)).Returns(expectedResult);

            //Act
            var actualResult = _controller.CreateKnapsack(problem);

            //Assert
            _mockKnapsackSolver.Verify(m => m.CreateKnapsack(problem.problem), Times.Once);
            Assert.IsNotNull(actualResult);
            Assert.IsInstanceOf(typeof(Task<IActionResult>), actualResult);
        }
    }
}